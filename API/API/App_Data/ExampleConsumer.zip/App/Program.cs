﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using UniversalWeather.Airport.API.Utilities;

namespace UniversalWeather.API.Consumer.Example
{
    class Program
    {
        //Set the Uri, apikey and secret key to a secured endpoint to test
        private static string UriAddress = "http://localhost:49248/api/v1/airports/testsecurity?golf=test&football=now&fishing=hello&lkey=fc5CWeUv1kaRzATnlXCYtg";
        private static string apiKey = "{get a API key per app}";
        private static string privateKey = "{get a private key}";

        static void Main(string[] args)
        {
            Uri uri = new Uri(UriAddress);
            var now = DateTime.UtcNow;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri.AbsoluteUri);
            request.Method = "POST";
            request.ContentLength = 0;

            // 1. Create the string to sign
            var stringToSign = CreateStringToSign(request, now.ToString("r"));

            // 2. Sign the string
            var signature = SignString(privateKey, stringToSign);

            // 3. Add the Date and X-UW-Authorization headers
            request.Date = now;
            request.Headers.Add("X-UW-Authorization", signature);

            // 4. Send
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                Console.WriteLine(reader.ReadToEnd());   
            }
        }

        /// <summary>
        /// Creates a hashed string using Hmac SHA256 and a private key.
        /// </summary>
        /// <param name="privateKey">User private key</param>
        /// <param name="stringToSign">String to sign</param>
        /// <returns>Signature</returns>
        private static string SignString(string privateKey, string stringToSign)
        {
            byte[] key = Encoding.UTF8.GetBytes(privateKey);
            byte[] message = Encoding.UTF8.GetBytes(stringToSign);
            using (var hmac = new HMACSHA256(key))
            {
                byte[] hash = hmac.ComputeHash(message);
                return Convert.ToBase64String(hash);
            }
        }

        /// <summary>
        /// Creates the string to sign in the correct format
        /// =================================================
        /// {Http Method}\n
        /// {Base Url}\n
        /// {Parameter-String}\n
        /// {Api-key}\n
        /// {timestamp Format RFC 1123}
        /// ==================================================
        /// Percent encode the timestamp.
        /// </summary>
        /// <param name="request"><see cref="HttpWebRequest"/></param>
        /// <returns>String to sign</returns>
        private static string CreateStringToSign(HttpWebRequest request, string timestamp)
        {
            string method = request.Method;
            string baseUrl = request.RequestUri.GetLeftPart(UriPartial.Path);
            string parameterString = BuildOrderedParameterString(request.RequestUri);
            string encodedTimestamp = Uri.EscapeDataString(timestamp);
            return string.Join("\n", new[] { 
                method, baseUrl, parameterString, apiKey, encodedTimestamp }
            );
        }

        /// <summary>
        /// Canonically reorder the querytring parameters. Percent encode all the
        /// query string keys and values
        /// </summary>
        /// <param name="uri"><see cref="HttpRequestMessage"/></param>
        /// <returns>Ordered parameter string</returns>
        private static string BuildOrderedParameterString(Uri uri)
        {
            var queryStringCollection = HttpUtility.ParseQueryString(uri.Query);
            var sortedList = new SortedDictionary<string, string>(
                queryStringCollection.AllKeys.ToDictionary(d => d,
                                                           d => queryStringCollection[d])
            ).Select(s => string.Format("{0}={1}", Uri.EscapeDataString(s.Key), Uri.EscapeDataString(s.Value))); 
            return string.Join("&", sortedList);
        }   
    }
}

